-- Written by Neil Kuehn, Christopher Doering
USE Pizzeria;
DROP TABLE IF EXISTS pizza_topping;
DROP TABLE IF EXISTS topping;
DROP TABLE IF EXISTS discount_order;
DROP TABLE IF EXISTS discount_pizza;
DROP TABLE IF EXISTS discount;
DROP TABLE IF EXISTS pizza;
DROP TABLE IF EXISTS customer_order;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS base;