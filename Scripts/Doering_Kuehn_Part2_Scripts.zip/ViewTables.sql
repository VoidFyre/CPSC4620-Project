-- Written by Neil Kuehn, Christopher Doering
USE Pizzeria;

SELECT * FROM base;
SELECT * FROM customer;
SELECT * FROM customer_order;
SELECT * FROM discount;
SELECT * FROM discount_order;
SELECT * FROM discount_pizza;
SELECT * FROM pizza;
SELECT * FROM pizza_topping;
SELECT * FROM topping;